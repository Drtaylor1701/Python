#! python3

def square(num):
    """This function calculates the square of a number"""
    result = num * num
    return result

for i in range(1, 11):
    print (square(i))


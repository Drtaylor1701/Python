#A short program that prints 5 lines of text.
print ("Gillian Weisgram")
print ("Star Trek is awesome.")
print ("Seriously, Star Trek Beyond is Mega-awesome.")
print ("Just go watch it, people.")
print ("Shamelessly plugging my favorites.")

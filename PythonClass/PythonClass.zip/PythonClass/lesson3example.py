name = "me"
if name == "me":
    print ("the same")

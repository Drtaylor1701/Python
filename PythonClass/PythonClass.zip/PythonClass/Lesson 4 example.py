#! python3

def print_welcome():
    """This function prints two lines of text."""
    print("Welcome to my program.")
    print("I hope you like it.")

print_welcome()
print()
print("To say again")
print()
print_welcome()
